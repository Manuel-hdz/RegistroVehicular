<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="row" style="justify-content: space-between;">
        <h2 style="margin:0">Mecánicos</h2>
        <a href="<?php echo e(route('mechanics.create')); ?>" class="btn btn-primary">Nuevo Mecánico</a>
    </div>
</div>

<div class="card">
    <table>
        <thead><tr><th>Nombre</th><th>Salario diario</th><th>Activo</th><th></th></tr></thead>
        <tbody>
            <?php $__currentLoopData = $mechanics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($m->name); ?></td>
                    <td>$<?php echo e(number_format($m->daily_salary, 2)); ?></td>
                    <td><?php echo e($m->active ? 'Sí' : 'No'); ?></td>
                    <td><a class="btn btn-secondary" href="<?php echo e(route('mechanics.edit', $m)); ?>">Editar</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div style="margin-top:12px;"><?php echo e($mechanics->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/mechanics/index.blade.php ENDPATH**/ ?>