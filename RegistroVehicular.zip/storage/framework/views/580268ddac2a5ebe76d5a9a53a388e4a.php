<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="row" style="justify-content: space-between;">
        <h2 style="margin:0">Vehículos</h2>
        <a href="<?php echo e(route('vehicles.create')); ?>" class="btn btn-primary">Nuevo Vehículo</a>
    </div>
</div>

<?php $__env->startPush('head-pre'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
        $(function(){
            $('#vehiclesTable').DataTable({
                pageLength: 25,
                order: [],
                language: { url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<div class="card">
    <table id="vehiclesTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Identificador</th>
                <th>Modelo</th>
                <th>Año</th>
                <th>Activo</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($v->identifier); ?></td>
                    <td><?php echo e($v->model); ?></td>
                    <td><?php echo e($v->year); ?></td>
                    <td><?php echo e($v->active ? 'Sí' : 'No'); ?></td>
                    <td>
                        <a class="btn btn-secondary" href="<?php echo e(route('vehicles.edit', $v)); ?>" title="Editar" aria-label="Editar">
                            <i class="bi bi-pencil-square" aria-hidden="true"></i>
                        </a>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->role === 'superadmin'): ?>
                                <form action="<?php echo e(route('vehicles.destroy', $v)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('¿Eliminar vehículo?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-secondary" type="submit" title="Eliminar" aria-label="Eliminar">
                                        <i class="bi bi-trash" aria-hidden="true" style="color:#dc2626;"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('head-pre'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/vehicles/index.blade.php ENDPATH**/ ?>