<?php $__env->startSection('content'); ?>
<?php $__env->startPush('head-pre'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('head'); ?>
<style>
  #departuresLayout { display:flex; gap:12px; align-items:flex-start; flex-wrap:wrap; }
  #departuresLayout > .main { flex: 1 1 700px; min-width:280px; }
  #departuresLayout > aside {
    flex: 0 0 320px;
    max-width: 320px;
    transition: flex-basis .25s ease, max-width .25s ease, opacity .25s ease, transform .25s ease;
    opacity: 1;
    transform: translateX(0);
  }
  @media (min-width: 992px) { #departuresLayout > aside { order: -1; } }
  #departuresLayout.collapsed > aside {
    flex-basis: 0 !important;
    max-width: 0 !important;
    opacity: 0;
    transform: translateX(12px);
    pointer-events: none;
  }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(4px);} to { opacity: 1; transform: translateY(0);} }
  #departuresLayout > .main { animation: fadeIn .25s ease; }
</style>
<?php $__env->stopPush(); ?>

<div class="card">
    <div class="row" style="justify-content: space-between; align-items: end; gap:10px;">
        <div>
            <h2 style="margin:0">Registros de Salidas</h2>
            <small style="color:#555;">Filtra por fecha, vehículo o conductor</small>
        </div>
        <div class="row" style="gap:8px;">
            <button type="button" class="btn btn-secondary" id="btnToggleFiltersDeps">
                <i class="bi bi-funnel" style="margin-right:6px;"></i>
                <span class="lbl">Ocultar filtros</span>
            </button>
            <a class="btn btn-secondary" href="<?php echo e(route('departures.export', request()->query())); ?>">Exportar CSV</a>
        </div>
    </div>
</div>

<div id="departuresLayout">
  <div class="card main">
    <table id="departuresTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Fecha/Hora Salida</th>
                <th>Vehículo</th>
                <th>Conductor</th>
                <th>Registró</th>
                <th>Estatus</th>
                <th>Destino</th>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role === 'superadmin'): ?>
                        <th>Acciones</th>
                    <?php endif; ?>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $departures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($m->id); ?></td>
                    <td><?php echo e($m->departed_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($m->vehicle->identifier); ?></td>
                    <td><?php echo e($m->driver->name); ?></td>
                    <td><?php echo e($m->guardOut?->name ?? '—'); ?></td>
                    <td>
                        <?php switch($m->status):
                            case ('closed'): ?>
                                <span style="display:inline-block; padding:4px 8px; border-radius:12px; background:#e9fff1; border:1px solid #a7f3d0; color:#065f46;">Completado</span>
                                <?php break; ?>
                            <?php case ('cancelled'): ?>
                                <span style="display:inline-block; padding:4px 8px; border-radius:12px; background:#fff7ed; border:1px solid #fed7aa; color:#9a3412;">Cancelado</span>
                                <?php break; ?>
                            <?php default: ?>
                                <span style="display:inline-block; padding:4px 8px; border-radius:12px; background:#eff6ff; border:1px solid #bfdbfe; color:#1d4ed8;">Abierto</span>
                        <?php endswitch; ?>
                    </td>
                    <td><?php echo e($m->destination); ?></td>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->role === 'superadmin'): ?>
                            <td style="display:flex; gap:6px; align-items:center;">
                                <a class="btn btn-secondary btn-icon" href="<?php echo e(route('movements.edit', $m)); ?>" title="Editar" aria-label="Editar">
                                    <i class="bi bi-pencil-square" aria-hidden="true"></i>
                                </a>
                                <?php if($m->status === 'open'): ?>
                                    <form action="<?php echo e(route('movements.cancel', $m)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('¿Seguro que deseas cancelar esta salida?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button class="btn btn-secondary btn-icon" type="submit" title="Cancelar" aria-label="Cancelar">
                                            <i class="bi bi-x-circle" aria-hidden="true" style="color:#dc2626;"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">Sin registros de salidas</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
  </div>

  <aside>
    <div class="card" style="position: sticky; top: 86px;">
        <h3 style="margin-top:0; font-size:18px;">Filtros</h3>
        <form method="GET" class="grid grid-3" style="gap:10px;">
            <div>
                <label style="font-size:14px;">Desde</label>
                <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>">
            </div>
            <div>
                <label style="font-size:14px;">Hasta</label>
                <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>">
            </div>
            <div>
                <label style="font-size:14px;">Destino</label>
                <input type="text" name="destination" value="<?php echo e(request('destination')); ?>" placeholder="Texto a buscar">
            </div>
            <div>
                <label style="font-size:14px;">Vehículo</label>
                <select name="vehicle_id">
                    <option value="">Todos</option>
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v->id); ?>" <?php if(request('vehicle_id')==$v->id): echo 'selected'; endif; ?>><?php echo e($v->identifier); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label style="font-size:14px;">Conductor</label>
                <select name="driver_id">
                    <option value="">Todos</option>
                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d->id); ?>" <?php if(request('driver_id')==$d->id): echo 'selected'; endif; ?>><?php echo e($d->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label style="font-size:14px;">Estatus</label>
                <select name="status">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>" <?php if(request('status','')===$k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="row" style="gap:8px; grid-column: 1/-1;">
                <button class="btn btn-primary" type="submit">Aplicar</button>
                <a class="btn btn-secondary" href="<?php echo e(route('departures.index')); ?>">Limpiar</a>
            </div>
        </form>
    </div>
  </aside>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
  (function(){
    const root = document.getElementById('departuresLayout');
    const btn = document.getElementById('btnToggleFiltersDeps');
    if (!root || !btn) return;
    function setLabel(){
      const lbl = root.classList.contains('collapsed') ? 'Mostrar filtros' : 'Ocultar filtros';
      const span = btn.querySelector('.lbl');
      if (span) span.textContent = lbl; else btn.innerHTML = lbl;
    }
    if (localStorage.getItem('depsFiltersCollapsed') === '1') {
      root.classList.add('collapsed');
    }
    setLabel();
    btn.addEventListener('click', function(){
      const willCollapse = !root.classList.contains('collapsed');
      root.classList.toggle('collapsed', willCollapse);
      localStorage.setItem('depsFiltersCollapsed', willCollapse ? '1' : '0');
      setLabel();
    });
  })();
  // Inicializar DataTable
  $(function(){
      var hasActions = $('#departuresTable thead th').last().text().trim() === 'Acciones';
      var opts = {
          pageLength: 25,
          order: [[0,'desc']],
          language: { url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' }
      };
      if (hasActions) {
          opts.columnDefs = [{ targets: -1, orderable: false, searchable: false }];
      }
      $('#departuresTable').DataTable(opts);
  });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/departures/index.blade.php ENDPATH**/ ?>