<?php $__env->startSection('content'); ?>
<div class="card">
    <h2 style="margin-top:0">Editar Conductor</h2>
    <form method="POST" action="<?php echo e(route('drivers.update', $driver)); ?>" class="grid grid-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label>Nombre</label>
            <input name="name" value="<?php echo e(old('name', $driver->name)); ?>" required>
        </div>
        <div>
            <label>Número de empleado</label>
            <input name="employee_number" value="<?php echo e(old('employee_number', $driver->employee_number)); ?>">
        </div>
        <div>
            <label>Licencia</label>
            <input name="license" value="<?php echo e(old('license', $driver->license)); ?>">
        </div>
        <div>
            <label><input type="checkbox" name="active" value="1" <?php echo e(old('active', $driver->active) ? 'checked' : ''); ?>> Activo</label>
        </div>
        <div style="grid-column: 1/-1;" class="row">
            <a class="btn btn-secondary" href="<?php echo e(route('drivers.index')); ?>">Cancelar</a>
            <button class="btn btn-primary" type="submit">Actualizar</button>
        </div>
    </form>
    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/drivers/edit.blade.php ENDPATH**/ ?>