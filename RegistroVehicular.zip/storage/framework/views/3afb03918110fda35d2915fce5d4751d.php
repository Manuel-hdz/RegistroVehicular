<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="row" style="justify-content: space-between; align-items:end;">
        <h2 style="margin:0">Reparaciones</h2>
        <a href="<?php echo e(route('repairs.create')); ?>" class="btn btn-primary">Nueva Reparación</a>
    </div>
</div>

<div class="card">
    <form method="GET" class="row" style="gap:10px; align-items:end;">
        <div>
            <label>Unidad</label>
            <select name="vehicle_id">
                <option value="">Todas</option>
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v->id); ?>" <?php if(request('vehicle_id')==$v->id): echo 'selected'; endif; ?>><?php echo e(($v->identifier ? $v->identifier.' — ' : '').$v->plate); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <button class="btn btn-secondary" type="submit">Filtrar</button>
            <a class="btn btn-link" href="<?php echo e(route('repairs.index')); ?>">Limpiar</a>
        </div>
    </form>
    <table>
        <thead><tr><th>Unidad</th><th>Inicio</th><th>Horas</th><th>Partes</th><th>Mecánicos</th><th>Costos</th></tr></thead>
        <tbody>
            <?php $__currentLoopData = $repairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(($r->vehicle->identifier ? $r->vehicle->identifier.' — ' : '').$r->vehicle->plate); ?></td>
                    <td><?php echo e($r->started_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($r->duration_hours); ?></td>
                    <td>
                        <?php $__currentLoopData = $r->parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($p->name); ?> × <?php echo e($p->pivot->quantity); ?> — $<?php echo e(number_format($p->unit_cost*$p->pivot->quantity,2)); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <?php $__currentLoopData = $r->mechanics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($m->name); ?> — <?php echo e($m->pivot->hours); ?> h</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <div>Refacciones: $<?php echo e(number_format($r->partsCost(),2)); ?></div>
                        <div>Mano de obra: $<?php echo e(number_format($r->laborCost(),2)); ?></div>
                        <strong>Total: $<?php echo e(number_format($r->totalCost(),2)); ?></strong>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div style="margin-top:12px;"><?php echo e($repairs->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/repairs/index.blade.php ENDPATH**/ ?>