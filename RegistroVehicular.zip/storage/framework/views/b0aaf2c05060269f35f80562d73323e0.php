<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="row" style="justify-content: space-between;">
        <h2 style="margin:0">Usuarios</h2>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Nuevo Usuario</a>
    </div>
</div>

<div class="card">
    <form method="GET" class="row" style="gap:10px; align-items:end; justify-content:flex-end; margin-bottom:10px;">
        <div>
            <label>Departamento</label>
            <select name="department">
                <?php $__currentLoopData = ($departments ?? [''=>'Todos']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k); ?>" <?php if(request('department','')===$k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <button class="btn btn-secondary" type="submit">Filtrar</button>
            <a class="btn btn-link" href="<?php echo e(route('users.index')); ?>">Limpiar</a>
        </div>
    </form>
    <?php if($users->total() > 0): ?>
        <div style="margin-bottom:10px; color:#555; font-size:14px; text-align:right;">
            Mostrando <?php echo e($users->firstItem()); ?> a <?php echo e($users->lastItem()); ?> de <?php echo e($users->total()); ?> resultados
            <?php if($users->hasPages()): ?>
                <span> · Página <?php echo e($users->currentPage()); ?> de <?php echo e($users->lastPage()); ?> ·
                <?php if($users->onFirstPage()): ?>
                    <span style="opacity:.6;">Anterior</span>
                <?php else: ?>
                    <a href="<?php echo e($users->previousPageUrl()); ?>">Anterior</a>
                <?php endif; ?>
                <span> | </span>
                <?php if($users->hasMorePages()): ?>
                    <a href="<?php echo e($users->nextPageUrl()); ?>">Siguiente</a>
                <?php else: ?>
                    <span style="opacity:.6;">Siguiente</span>
                <?php endif; ?>
                </span>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <table>
        <thead>
        <tr>
            <th>Nombre</th>
            <th>Usuario</th>
            <th>Rol</th>
            <th>Departamento</th>
            <th>Activo</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($u->name); ?></td>
                <td><?php echo e($u->username); ?></td>
                <td style="text-transform:uppercase;"><?php echo e($u->role); ?></td>
                <td><?php echo e($u->department ? ucfirst($u->department) : '—'); ?></td>
                <td><?php echo e($u->active ? 'Sí' : 'No'); ?></td>
                <td>
                    <a class="btn btn-secondary" href="<?php echo e(route('users.edit', $u)); ?>?page=<?php echo e($users->currentPage()); ?>">Editar</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if($users->total() > 0): ?>
        <div style="margin-top:12px; color:#555; font-size:14px; text-align:right;">
            Mostrando <?php echo e($users->firstItem()); ?> a <?php echo e($users->lastItem()); ?> de <?php echo e($users->total()); ?> resultados
        </div>
        <?php if($users->hasPages()): ?>
            <div style="margin-top:6px; color:#555; font-size:14px; text-align:right;">
                Página <?php echo e($users->currentPage()); ?> de <?php echo e($users->lastPage()); ?> ·
                <?php if($users->onFirstPage()): ?>
                    <span style="opacity:.6;">Anterior</span>
                <?php else: ?>
                    <a href="<?php echo e($users->previousPageUrl()); ?>">Anterior</a>
                <?php endif; ?>
                <span> | </span>
                <?php if($users->hasMorePages()): ?>
                    <a href="<?php echo e($users->nextPageUrl()); ?>">Siguiente</a>
                <?php else: ?>
                    <span style="opacity:.6;">Siguiente</span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/users/index.blade.php ENDPATH**/ ?>