<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:480px; margin:40px auto;">
    <h2 style="margin-top:0">Iniciar sesión</h2>
    <form method="POST" action="<?php echo e(route('login.post')); ?>" class="grid">
        <?php echo csrf_field(); ?>
        <div>
            <label>Usuario</label>
            <input type="text" name="username" value="<?php echo e(old('username')); ?>" required>
        </div>
        <div>
            <label>Contraseña</label>
            <input type="password" name="password" required>
        </div>
        <label style="display:flex; gap:8px; align-items:center; margin:4px 0 12px 0;">
            <input type="checkbox" name="remember" value="1"> Recordarme
        </label>
        <div class="row">
            <button class="btn btn-primary" type="submit">Entrar</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/auth/login.blade.php ENDPATH**/ ?>