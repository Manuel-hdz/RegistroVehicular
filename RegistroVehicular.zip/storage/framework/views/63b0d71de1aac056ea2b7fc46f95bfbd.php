<?php $__env->startSection('content'); ?>
<div class="card">
    <h2 style="margin-top:0">Nuevo Conductor</h2>
    <form method="POST" action="<?php echo e(route('drivers.store')); ?>" class="grid grid-3">
        <?php echo csrf_field(); ?>
        <div>
            <label>Nombre</label>
            <input name="name" value="<?php echo e(old('name')); ?>" required>
        </div>
        <div>
            <label>Número de empleado</label>
            <input name="employee_number" value="<?php echo e(old('employee_number')); ?>">
        </div>
        <div>
            <label>Licencia</label>
            <input name="license" value="<?php echo e(old('license')); ?>">
        </div>
        <div>
            <label><input type="checkbox" name="active" value="1" checked> Activo</label>
        </div>
        <div style="grid-column: 1/-1;" class="row">
            <a class="btn btn-secondary" href="<?php echo e(route('drivers.index')); ?>">Cancelar</a>
            <button class="btn btn-primary" type="submit">Guardar</button>
        </div>
    </form>
    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/drivers/create.blade.php ENDPATH**/ ?>