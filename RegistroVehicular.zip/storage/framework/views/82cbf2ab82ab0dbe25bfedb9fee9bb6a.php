<?php $__env->startSection('content'); ?>
<div class="card">
    <h2 style="margin-top:0">Nueva Reparación</h2>
    <form method="POST" action="<?php echo e(route('repairs.store')); ?>" class="grid">
        <?php echo csrf_field(); ?>
        <div class="grid grid-3">
            <div>
                <label>Unidad</label>
                <select name="vehicle_id" required>
                    <option value="">Seleccione…</option>
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($v->id); ?>" <?php if(old('vehicle_id')==$v->id): echo 'selected'; endif; ?>><?php echo e(($v->identifier ? $v->identifier.' — ' : '').$v->plate); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label>Inicio</label>
                <input type="datetime-local" name="started_at" value="<?php echo e(old('started_at')); ?>">
            </div>
            <div>
                <label>Duración (horas)</label>
                <input type="number" step="0.25" name="duration_hours" value="<?php echo e(old('duration_hours', 1)); ?>" min="0" required>
            </div>
        </div>

        <div class="grid grid-3">
            <div>
                <label>Refacciones</label>
                <div id="partsRepeater">
                    <?php for($i=0;$i<3;$i++): ?>
                        <div class="row" style="gap:6px; margin-bottom:6px;">
                            <select name="parts[<?php echo e($i); ?>][id]">
                                <option value="">—</option>
                                <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?> ($<?php echo e(number_format($p->unit_cost,2)); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="number" name="parts[<?php echo e($i); ?>][qty]" min="1" value="1" style="width:100px;">
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
            <div>
                <label>Mecánicos</label>
                <div id="mechsRepeater">
                    <?php for($i=0;$i<3;$i++): ?>
                        <div class="row" style="gap:6px; margin-bottom:6px;">
                            <select name="mechanics[<?php echo e($i); ?>][id]">
                                <option value="">—</option>
                                <?php $__currentLoopData = $mechanics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($m->id); ?>"><?php echo e($m->name); ?> ($<?php echo e(number_format($m->daily_salary,2)); ?>/día)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="number" step="0.25" name="mechanics[<?php echo e($i); ?>][hours]" min="0" value="1" style="width:120px;">
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
            <div>
                <label>Notas</label>
                <textarea name="notes"><?php echo e(old('notes')); ?></textarea>
            </div>
        </div>

        <div class="row actions-stick">
            <a class="btn btn-secondary" href="<?php echo e(route('repairs.index')); ?>">Cancelar</a>
            <button class="btn btn-primary" type="submit">Guardar</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/repairs/create.blade.php ENDPATH**/ ?>