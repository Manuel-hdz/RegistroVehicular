<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="row" style="justify-content: space-between;">
        <h2 style="margin:0">Refacciones</h2>
        <a href="<?php echo e(route('parts.create')); ?>" class="btn btn-primary">Nueva Refacción</a>
    </div>
</div>

<div class="card">
    <table>
        <thead><tr><th>Nombre</th><th>Costo</th><th>Activa</th><th></th></tr></thead>
        <tbody>
            <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($p->name); ?></td>
                    <td>$<?php echo e(number_format($p->unit_cost, 2)); ?></td>
                    <td><?php echo e($p->active ? 'Sí' : 'No'); ?></td>
                    <td><a class="btn btn-secondary" href="<?php echo e(route('parts.edit', $p)); ?>">Editar</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div style="margin-top:12px;"><?php echo e($parts->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/parts/index.blade.php ENDPATH**/ ?>