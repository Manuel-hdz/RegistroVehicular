<?php $__env->startSection('content'); ?>
<?php $__env->startPush('head-pre'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<div class="card">
    <div class="row" style="justify-content: space-between;">
        <h2 style="margin:0">Movimientos</h2>
        <a href="<?php echo e(route('movements.create')); ?>" class="btn btn-primary">Registrar Salida</a>
    </div>
</div>

<div class="card">
    <h3 style="margin-top:0">Abiertos</h3>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Vehículo</th>
                <th>Conductor</th>
                <th>Odómetro Salida</th>
                <th>Combustible Salida</th>
                <th>Fecha/Hora Salida</th>
                <th>Destino</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $open; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($m->id); ?></td>
                    <td><?php echo e($m->vehicle->identifier); ?></td>
                    <td><?php echo e($m->driver->name); ?></td>
                    <td><?php echo e($m->odometer_out); ?></td>
                    <td><?php echo e($m->fuel_out); ?>%</td>
                    <td><?php echo e($m->departed_at->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($m->destination); ?></td>
                    <td>
                        <a class="btn btn-warning" href="<?php echo e(route('movements.checkin.form', $m)); ?>">Registrar Entrada</a>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->role === 'superadmin'): ?>
                                <div style="margin-top:6px; display:flex; gap:6px; align-items:center;">
                                    <a class="btn btn-secondary btn-icon" href="<?php echo e(route('movements.edit', $m)); ?>" title="Editar" aria-label="Editar">
                                        <i class="bi bi-pencil-square" aria-hidden="true"></i>
                                    </a>
                                    <form action="<?php echo e(route('movements.cancel', $m)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('¿Seguro que deseas cancelar esta salida?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button class="btn btn-secondary btn-icon" type="submit" title="Cancelar" aria-label="Cancelar">
                                            <i class="bi bi-x-circle" aria-hidden="true" style="color:#dc2626;"></i>
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7">Sin movimientos abiertos</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    
</div>

<div class="card">
    <h3 style="margin-top:0">Cerrados Recientes</h3>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Vehículo</th>
                <th>Conductor</th>
                <th>Salida</th>
                <th>Entrada</th>
                <th>Km Recorridos</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $recentClosed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($m->id); ?></td>
                    <td><?php echo e($m->vehicle->identifier); ?></td>
                    <td><?php echo e($m->driver->name); ?></td>
                    <td><?php echo e($m->departed_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e($m->arrived_at?->format('Y-m-d H:i')); ?></td>
                    <td><?php echo e(($m->odometer_in ?? 0) - ($m->odometer_out ?? 0)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">Sin historial</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/movements/index.blade.php ENDPATH**/ ?>