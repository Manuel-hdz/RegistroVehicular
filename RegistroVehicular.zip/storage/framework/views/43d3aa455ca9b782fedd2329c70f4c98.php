<?php $__env->startSection('content'); ?>
<div class="card">
    <h2 style="margin-top:0">Registrar Salida</h2>
    <form method="POST" action="<?php echo e(route('movements.store')); ?>" class="grid grid-3" onsubmit="return confirm('Antes de guardar, por favor revisa que los datos sean correctos (vehículo, conductor, odómetro, combustible y fecha/hora). ¿Deseas continuar?')">
        <?php echo csrf_field(); ?>
        <div>
            <label>Vehículo</label>
            <select name="vehicle_id" required>
                <option value="">Seleccione…</option>
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v->id); ?>" <?php if(old('vehicle_id')==$v->id): echo 'selected'; endif; ?>>
                        <?php echo e($v->identifier ?: $v->plate); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>Conductor</label>
            <select name="driver_id" required>
                <option value="">Seleccione…</option>
                <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($d->id); ?>" <?php if(old('driver_id')==$d->id): echo 'selected'; endif; ?>><?php echo e($d->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label>Odómetro salida (km)</label>
            <input type="number" name="odometer_out" value="<?php echo e(old('odometer_out')); ?>" min="0" required>
        </div>
        <div>
            <label>Combustible salida</label>
            <div class="row" style="gap:8px;">
                <select name="fuel_out_base" required>
                    <option value="1/4" <?php if(old('fuel_out_base')==='1/4'): echo 'selected'; endif; ?>>1/4</option>
                    <option value="1/2" <?php if(old('fuel_out_base','1/2')==='1/2'): echo 'selected'; endif; ?>>1/2</option>
                    <option value="3/4" <?php if(old('fuel_out_base')==='3/4'): echo 'selected'; endif; ?>>3/4</option>
                    <option value="1" <?php if(old('fuel_out_base')==='1'): echo 'selected'; endif; ?>>Lleno</option>
                </select>
                <select name="fuel_out_dir" required>
                    <option value="below" <?php if(old('fuel_out_dir')==='below'): echo 'selected'; endif; ?>>Abajo de</option>
                    <option value="exact" <?php if(old('fuel_out_dir','exact')==='exact'): echo 'selected'; endif; ?>>Exacto</option>
                    <option value="above" <?php if(old('fuel_out_dir')==='above'): echo 'selected'; endif; ?>>Arriba de</option>
                </select>
            </div>
            <small style="color:#555;">Se almacenará como porcentaje aproximado.</small>
        </div>
        <div>
            <label>Fecha/Hora salida</label>
            <input type="datetime-local" name="departed_at" value="<?php echo e(old('departed_at', now()->format('Y-m-d\TH:i'))); ?>" required>
        </div>
        <div>
            <label>Destino</label>
            <input type="text" name="destination" value="<?php echo e(old('destination')); ?>">
        </div>
        <div class="grid" style="grid-column: 1/-1;">
            <label>Notas</label>
            <textarea name="notes_out"><?php echo e(old('notes_out')); ?></textarea>
        </div>
        <div style="grid-column: 1/-1;" class="row actions-stick">
            <a class="btn btn-secondary" href="<?php echo e(route('movements.index')); ?>">Cancelar</a>
            <button class="btn btn-primary" type="submit">Guardar Salida</button>
        </div>
    </form>
</div>
<script>
    (function(){
        var input = document.querySelector('input[name="departed_at"]');
        if(input){
            var d = new Date();
            var yyyy = d.getFullYear();
            var mm = String(d.getMonth()+1).padStart(2,'0');
            var dd = String(d.getDate()).padStart(2,'0');
            input.value = yyyy + '-' + mm + '-' + dd + 'T08:00';
        }
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/movements/create.blade.php ENDPATH**/ ?>