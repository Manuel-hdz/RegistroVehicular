<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="row" style="justify-content: space-between;">
        <h2 style="margin:0">Conductores</h2>
        <a href="<?php echo e(route('drivers.create')); ?>" class="btn btn-primary">Nuevo Conductor</a>
    </div>
</div>

<?php $__env->startPush('head-pre'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
        $(function(){
            $('#driversTable').DataTable({
                pageLength: 25,
                order: [[0,'asc']],
                language: { url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<div class="card">
    <table id="driversTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Número</th>
                <th>Licencia</th>
                <th>Activo</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($d->name); ?></td>
                    <td><?php echo e($d->employee_number); ?></td>
                    <td><?php echo e($d->license); ?></td>
                    <td><?php echo e($d->active ? 'Sí' : 'No'); ?></td>
                    <td>
                        <a class="btn btn-secondary" href="<?php echo e(route('drivers.edit', $d)); ?>" title="Editar" aria-label="Editar">
                            <i class="bi bi-pencil-square" aria-hidden="true"></i>
                        </a>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->role === 'superadmin'): ?>
                                <form action="<?php echo e(route('drivers.destroy', $d)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('¿Eliminar conductor?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-secondary" type="submit" title="Eliminar" aria-label="Eliminar">
                                        <i class="bi bi-trash" aria-hidden="true" style="color:#dc2626;"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('head-pre'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/drivers/index.blade.php ENDPATH**/ ?>