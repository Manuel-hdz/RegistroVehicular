<?php $__env->startSection('content'); ?>
<div class="card">
    <h2 style="margin-top:0">Nuevo Usuario (Solo SuperAdmin)</h2>
    <form method="POST" action="<?php echo e(route('users.store')); ?>" class="grid grid-3">
        <?php echo csrf_field(); ?>
        <div>
            <label>Nombre</label>
            <input name="name" value="<?php echo e(old('name')); ?>" required>
        </div>
        <div>
            <label>Usuario</label>
            <input type="text" name="username" value="<?php echo e(old('username')); ?>" required>
        </div>
        <div>
            <label>Contraseña</label>
            <input type="password" name="password" required>
        </div>
        <div>
            <label>Rol</label>
            <select name="role" required>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k); ?>" <?php if(old('role')===$k): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label><input type="checkbox" name="active" value="1" checked> Activo</label>
        </div>
        <div style="grid-column: 1/-1;" class="row actions-stick">
            <a class="btn btn-secondary" href="<?php echo e(route('users.index')); ?>">Cancelar</a>
            <button class="btn btn-primary" type="submit">Guardar</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/users/create.blade.php ENDPATH**/ ?>