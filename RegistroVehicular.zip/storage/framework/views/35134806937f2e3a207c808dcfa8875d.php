<?php $__env->startSection('content'); ?>
<div class="card">
    <h2 style="margin-top:0">Registrar Entrada</h2>
    <p>
        Vehículo: <strong><?php echo e($movement->vehicle->identifier ? $movement->vehicle->identifier . ' — ' : ''); ?><?php echo e($movement->vehicle->plate); ?></strong> — Conductor: <strong><?php echo e($movement->driver->name); ?></strong><br>
        Salida: <?php echo e($movement->departed_at->format('Y-m-d H:i')); ?>, Odómetro: <?php echo e($movement->odometer_out); ?> km, Comb.: <?php echo e($movement->fuel_out); ?>%
    </p>
    <form method="POST" action="<?php echo e(route('movements.checkin', $movement)); ?>" class="grid grid-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label>Odómetro entrada (km)</label>
            <input type="number" name="odometer_in" value="<?php echo e(old('odometer_in', $movement->odometer_out)); ?>" min="<?php echo e($movement->odometer_out); ?>" required>
        </div>
        <div>
            <label>Combustible entrada</label>
            <div class="row" style="gap:8px;">
                <select name="fuel_in_base" required>
                    <option value="1/4" <?php if(old('fuel_in_base')==='1/4'): echo 'selected'; endif; ?>>1/4</option>
                    <option value="1/2" <?php if(old('fuel_in_base','1/2')==='1/2'): echo 'selected'; endif; ?>>1/2</option>
                    <option value="3/4" <?php if(old('fuel_in_base')==='3/4'): echo 'selected'; endif; ?>>3/4</option>
                    <option value="1" <?php if(old('fuel_in_base')==='1'): echo 'selected'; endif; ?>>Lleno</option>
                </select>
                <select name="fuel_in_dir" required>
                    <option value="below" <?php if(old('fuel_in_dir')==='below'): echo 'selected'; endif; ?>>Abajo de</option>
                    <option value="exact" <?php if(old('fuel_in_dir','exact')==='exact'): echo 'selected'; endif; ?>>Exacto</option>
                    <option value="above" <?php if(old('fuel_in_dir')==='above'): echo 'selected'; endif; ?>>Arriba de</option>
                </select>
            </div>
            <small style="color:#555;">Se almacenará como porcentaje aproximado.</small>
        </div>
        <div>
            <label>Fecha/Hora entrada</label>
            <input type="datetime-local" name="arrived_at" value="<?php echo e(old('arrived_at', now()->format('Y-m-d\TH:i'))); ?>" required>
        </div>
        <div class="grid" style="grid-column: 1/-1;">
            <label>Notas</label>
            <textarea name="notes_in"><?php echo e(old('notes_in')); ?></textarea>
        </div>
        <div style="grid-column: 1/-1;" class="row actions-stick">
            <a class="btn btn-secondary" href="<?php echo e(route('movements.index')); ?>">Cancelar</a>
            <button class="btn btn-warning" type="submit">Guardar Entrada</button>
        </div>
    </form>
    
</div>
<script>
    (function(){
        var input = document.querySelector('input[name="arrived_at"]');
        if(input && !input.value){
            var d = new Date();
            var yyyy = d.getFullYear();
            var mm = String(d.getMonth()+1).padStart(2,'0');
            var dd = String(d.getDate()).padStart(2,'0');
            input.value = yyyy + '-' + mm + '-' + dd + 'T08:00';
        }
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\clfma\Documents\Proyectos\RegistroVehicular\resources\views/movements/checkin.blade.php ENDPATH**/ ?>