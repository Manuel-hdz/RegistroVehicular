Coloca aquí el logotipo de la empresa para que se muestre en la aplicación.

Nombre sugerido: logo_marca.png

Ruta esperada por las vistas:
  public/images/logo_marca.png

Formato recomendado: PNG (con fondo transparente) o SVG.

